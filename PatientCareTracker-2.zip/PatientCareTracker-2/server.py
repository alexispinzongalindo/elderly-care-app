from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import sqlite3
import json
from datetime import datetime
import os

app = Flask(__name__, static_folder='.')
CORS(app)

DATABASE = 'patient_care.db'

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS medications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            dosage TEXT NOT NULL,
            frequency TEXT NOT NULL,
            time_slots TEXT NOT NULL,
            start_date DATETIME,
            end_date DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            active BOOLEAN DEFAULT 1
        )
    ''')
    
    cursor.execute("PRAGMA table_info(medications)")
    columns = [column[1] for column in cursor.fetchall()]
    if 'start_date' not in columns:
        cursor.execute('ALTER TABLE medications ADD COLUMN start_date DATETIME')
    if 'end_date' not in columns:
        cursor.execute('ALTER TABLE medications ADD COLUMN end_date DATETIME')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS medication_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            medication_id INTEGER NOT NULL,
            taken_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            scheduled_time TEXT NOT NULL,
            status TEXT NOT NULL,
            FOREIGN KEY (medication_id) REFERENCES medications (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS appointments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date DATE NOT NULL,
            time TIME NOT NULL,
            doctor_name TEXT NOT NULL,
            facility TEXT,
            purpose TEXT,
            notes TEXT,
            completed BOOLEAN DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS exercises (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            duration_minutes INTEGER,
            sets INTEGER,
            reps INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS exercise_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exercise_id INTEGER NOT NULL,
            completed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            duration_actual INTEGER,
            notes TEXT,
            FOREIGN KEY (exercise_id) REFERENCES exercises (id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vital_signs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            systolic INTEGER,
            diastolic INTEGER,
            glucose REAL,
            weight REAL,
            notes TEXT
        )
    ''')
    
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('.', path)

@app.route('/api/medications', methods=['GET', 'POST'])
def medications():
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'GET':
        cursor.execute('SELECT * FROM medications WHERE active = 1 ORDER BY created_at DESC')
        meds = []
        for row in cursor.fetchall():
            med = dict(row)
            
            cursor.execute('''
                SELECT taken_at, scheduled_time FROM medication_logs 
                WHERE medication_id = ? AND status = 'taken'
                ORDER BY taken_at DESC LIMIT 1
            ''', (med['id'],))
            last_log = cursor.fetchone()
            
            if last_log:
                med['last_taken'] = last_log['taken_at']
                med['last_taken_time'] = last_log['scheduled_time']
                
                from datetime import datetime, timedelta
                last_taken_dt = datetime.fromisoformat(last_log['taken_at'])
                
                frequency = med['frequency']
                if 'hour' in frequency.lower():
                    hours = int(''.join(filter(str.isdigit, frequency)) or 0)
                    next_dose = last_taken_dt + timedelta(hours=hours)
                elif frequency == 'once_daily':
                    next_dose = last_taken_dt + timedelta(days=1)
                elif frequency == 'twice_daily':
                    next_dose = last_taken_dt + timedelta(hours=12)
                elif frequency == 'three_times_daily':
                    next_dose = last_taken_dt + timedelta(hours=8)
                else:
                    next_dose = None
                
                if next_dose:
                    med['next_dose'] = next_dose.isoformat()
            else:
                med['last_taken'] = None
                med['last_taken_time'] = None
                med['next_dose'] = None
            
            meds.append(med)
        
        conn.close()
        return jsonify(meds)
    
    elif request.method == 'POST':
        data = request.json
        cursor.execute('''
            INSERT INTO medications (name, dosage, frequency, time_slots, start_date, end_date)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (data['name'], data['dosage'], data['frequency'], json.dumps(data['time_slots']), 
              data.get('start_date'), data.get('end_date')))
        conn.commit()
        med_id = cursor.lastrowid
        conn.close()
        return jsonify({'id': med_id, 'message': 'Medication added successfully'}), 201

@app.route('/api/medications/<int:id>', methods=['PUT', 'DELETE'])
def medication_detail(id):
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'PUT':
        data = request.json
        cursor.execute('''
            UPDATE medications 
            SET name = ?, dosage = ?, frequency = ?, time_slots = ?, start_date = ?, end_date = ?
            WHERE id = ?
        ''', (data['name'], data['dosage'], data['frequency'], json.dumps(data['time_slots']), 
              data.get('start_date'), data.get('end_date'), id))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Medication updated successfully'})
    
    elif request.method == 'DELETE':
        cursor.execute('UPDATE medications SET active = 0 WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Medication deleted successfully'})

@app.route('/api/medications/<int:id>/log', methods=['POST'])
def log_medication(id):
    conn = get_db()
    cursor = conn.cursor()
    data = request.json
    
    cursor.execute('''
        INSERT INTO medication_logs (medication_id, scheduled_time, status)
        VALUES (?, ?, ?)
    ''', (id, data['scheduled_time'], data['status']))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Medication logged successfully'}), 201

@app.route('/api/medications/<int:id>/logs', methods=['GET'])
def get_medication_logs(id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM medication_logs 
        WHERE medication_id = ? 
        AND DATE(taken_at) = DATE('now')
        ORDER BY taken_at DESC
    ''', (id,))
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(logs)

@app.route('/api/medication-logs/<int:id>', methods=['PUT', 'DELETE'])
def medication_log_detail(id):
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'PUT':
        data = request.json
        cursor.execute('''
            UPDATE medication_logs 
            SET scheduled_time = ?, status = ?, taken_at = ?
            WHERE id = ?
        ''', (data['scheduled_time'], data['status'], data.get('taken_at', datetime.now().isoformat()), id))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Medication log updated successfully'})
    
    elif request.method == 'DELETE':
        cursor.execute('DELETE FROM medication_logs WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Medication log deleted successfully'})

@app.route('/api/appointments', methods=['GET', 'POST'])
def appointments():
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'GET':
        cursor.execute('SELECT * FROM appointments ORDER BY date, time')
        appts = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return jsonify(appts)
    
    elif request.method == 'POST':
        data = request.json
        cursor.execute('''
            INSERT INTO appointments (date, time, doctor_name, facility, purpose, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (data['date'], data['time'], data['doctor_name'], 
              data.get('facility', ''), data.get('purpose', ''), data.get('notes', '')))
        conn.commit()
        appt_id = cursor.lastrowid
        conn.close()
        return jsonify({'id': appt_id, 'message': 'Appointment added successfully'}), 201

@app.route('/api/appointments/<int:id>', methods=['PUT', 'DELETE'])
def appointment_detail(id):
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'PUT':
        data = request.json
        cursor.execute('''
            UPDATE appointments 
            SET date = ?, time = ?, doctor_name = ?, facility = ?, 
                purpose = ?, notes = ?, completed = ?
            WHERE id = ?
        ''', (data['date'], data['time'], data['doctor_name'], 
              data.get('facility', ''), data.get('purpose', ''), 
              data.get('notes', ''), data.get('completed', 0), id))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Appointment updated successfully'})
    
    elif request.method == 'DELETE':
        cursor.execute('DELETE FROM appointments WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Appointment deleted successfully'})

@app.route('/api/appointments/upcoming', methods=['GET'])
def upcoming_appointments():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM appointments 
        WHERE date >= DATE('now') AND completed = 0
        ORDER BY date, time
        LIMIT 10
    ''')
    appts = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(appts)

@app.route('/api/exercises', methods=['GET', 'POST'])
def exercises():
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'GET':
        cursor.execute('SELECT * FROM exercises ORDER BY created_at DESC')
        exs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return jsonify(exs)
    
    elif request.method == 'POST':
        data = request.json
        cursor.execute('''
            INSERT INTO exercises (name, description, duration_minutes, sets, reps)
            VALUES (?, ?, ?, ?, ?)
        ''', (data['name'], data.get('description', ''), 
              data.get('duration_minutes'), data.get('sets'), data.get('reps')))
        conn.commit()
        ex_id = cursor.lastrowid
        conn.close()
        return jsonify({'id': ex_id, 'message': 'Exercise added successfully'}), 201

@app.route('/api/exercises/<int:id>/log', methods=['POST'])
def log_exercise(id):
    conn = get_db()
    cursor = conn.cursor()
    data = request.json
    
    cursor.execute('''
        INSERT INTO exercise_logs (exercise_id, duration_actual, notes)
        VALUES (?, ?, ?)
    ''', (id, data.get('duration_actual'), data.get('notes', '')))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Exercise logged successfully'}), 201

@app.route('/api/exercises/logs', methods=['GET'])
def exercise_logs():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT el.*, e.name as exercise_name 
        FROM exercise_logs el
        JOIN exercises e ON el.exercise_id = e.id
        WHERE DATE(el.completed_at) = DATE('now')
        ORDER BY el.completed_at DESC
    ''')
    logs = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(logs)

@app.route('/api/exercise-logs/<int:id>', methods=['PUT', 'DELETE'])
def exercise_log_detail(id):
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'PUT':
        data = request.json
        cursor.execute('''
            UPDATE exercise_logs 
            SET duration_actual = ?, notes = ?, completed_at = ?
            WHERE id = ?
        ''', (data.get('duration_actual'), data.get('notes', ''), data.get('completed_at', datetime.now().isoformat()), id))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Exercise log updated successfully'})
    
    elif request.method == 'DELETE':
        cursor.execute('DELETE FROM exercise_logs WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Exercise log deleted successfully'})

@app.route('/api/dashboard', methods=['GET'])
def dashboard():
    conn = get_db()
    cursor = conn.cursor()
    
    cursor.execute('SELECT COUNT(*) as count FROM medications WHERE active = 1')
    total_meds = cursor.fetchone()['count']
    
    cursor.execute('''
        SELECT COUNT(*) as count FROM medication_logs 
        WHERE DATE(taken_at) = DATE('now') AND status = 'taken'
    ''')
    meds_taken_today = cursor.fetchone()['count']
    
    cursor.execute('''
        SELECT COUNT(*) as count FROM appointments 
        WHERE date = DATE('now') AND completed = 0
    ''')
    appts_today = cursor.fetchone()['count']
    
    cursor.execute('''
        SELECT COUNT(*) as count FROM exercise_logs 
        WHERE DATE(completed_at) = DATE('now')
    ''')
    exercises_today = cursor.fetchone()['count']
    
    conn.close()
    
    return jsonify({
        'total_medications': total_meds,
        'medications_taken_today': meds_taken_today,
        'appointments_today': appts_today,
        'exercises_completed_today': exercises_today
    })

@app.route('/api/calendar', methods=['GET'])
def calendar():
    conn = get_db()
    cursor = conn.cursor()
    
    month = request.args.get('month')
    
    activities = []
    
    if month:
        cursor.execute('''
            SELECT ml.*, m.name as medication_name, m.dosage
            FROM medication_logs ml
            JOIN medications m ON ml.medication_id = m.id
            WHERE strftime('%Y-%m', ml.taken_at) = ?
            ORDER BY ml.taken_at DESC
        ''', (month,))
    else:
        cursor.execute('''
            SELECT ml.*, m.name as medication_name, m.dosage
            FROM medication_logs ml
            JOIN medications m ON ml.medication_id = m.id
            ORDER BY ml.taken_at DESC
            LIMIT 500
        ''')
    for row in cursor.fetchall():
        activities.append({
            'type': 'medication',
            'id': row['id'],
            'datetime': row['taken_at'],
            'scheduled_time': row['scheduled_time'],
            'status': row['status'],
            'name': row['medication_name'],
            'dosage': row['dosage'],
            'medication_id': row['medication_id']
        })
    
    if month:
        cursor.execute('''
            SELECT * FROM appointments
            WHERE strftime('%Y-%m', date) = ?
            ORDER BY date DESC, time DESC
        ''', (month,))
    else:
        cursor.execute('''
            SELECT * FROM appointments
            ORDER BY date DESC, time DESC
            LIMIT 500
        ''')
    for row in cursor.fetchall():
        activities.append({
            'type': 'appointment',
            'id': row['id'],
            'datetime': row['date'] + ' ' + row['time'],
            'date': row['date'],
            'time': row['time'],
            'name': row['doctor_name'],
            'facility': row['facility'],
            'purpose': row['purpose'],
            'notes': row['notes'],
            'completed': row['completed']
        })
    
    if month:
        cursor.execute('''
            SELECT el.*, e.name as exercise_name, e.description
            FROM exercise_logs el
            JOIN exercises e ON el.exercise_id = e.id
            WHERE strftime('%Y-%m', el.completed_at) = ?
            ORDER BY el.completed_at DESC
        ''', (month,))
    else:
        cursor.execute('''
            SELECT el.*, e.name as exercise_name, e.description
            FROM exercise_logs el
            JOIN exercises e ON el.exercise_id = e.id
            ORDER BY el.completed_at DESC
            LIMIT 500
        ''')
    for row in cursor.fetchall():
        activities.append({
            'type': 'exercise',
            'id': row['id'],
            'datetime': row['completed_at'],
            'name': row['exercise_name'],
            'description': row['description'],
            'duration': row['duration_actual'],
            'notes': row['notes'],
            'exercise_id': row['exercise_id']
        })
    
    activities.sort(key=lambda x: x['datetime'], reverse=True)
    
    conn.close()
    return jsonify(activities)

@app.route('/api/vital-signs', methods=['GET', 'POST'])
def vital_signs():
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'GET':
        cursor.execute('SELECT * FROM vital_signs ORDER BY recorded_at DESC')
        signs = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return jsonify(signs)
    
    elif request.method == 'POST':
        data = request.json
        cursor.execute('''
            INSERT INTO vital_signs (recorded_at, systolic, diastolic, glucose, weight, notes)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            data.get('recorded_at'),
            data.get('systolic'),
            data.get('diastolic'),
            data.get('glucose'),
            data.get('weight'),
            data.get('notes', '')
        ))
        conn.commit()
        sign_id = cursor.lastrowid
        conn.close()
        return jsonify({'id': sign_id, 'message': 'Vital signs recorded successfully'}), 201

@app.route('/api/vital-signs/<int:sign_id>', methods=['PUT', 'DELETE'])
def vital_sign_detail(sign_id):
    conn = get_db()
    cursor = conn.cursor()
    
    if request.method == 'PUT':
        data = request.json
        cursor.execute('''
            UPDATE vital_signs 
            SET recorded_at = ?, systolic = ?, diastolic = ?, glucose = ?, weight = ?, notes = ?
            WHERE id = ?
        ''', (
            data.get('recorded_at'),
            data.get('systolic'),
            data.get('diastolic'),
            data.get('glucose'),
            data.get('weight'),
            data.get('notes', ''),
            sign_id
        ))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Vital signs updated successfully'})
    
    elif request.method == 'DELETE':
        cursor.execute('DELETE FROM vital_signs WHERE id = ?', (sign_id,))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Vital signs deleted successfully'})

@app.route('/api/vital-signs/bulk-import', methods=['POST'])
def vital_signs_bulk_import():
    conn = get_db()
    cursor = conn.cursor()
    
    data = request.json
    records = data.get('records', [])
    
    if not records:
        conn.close()
        return jsonify({'message': 'No records provided'}), 400
    
    imported_count = 0
    
    for record in records:
        try:
            cursor.execute('''
                INSERT INTO vital_signs (recorded_at, systolic, diastolic, glucose, weight, notes)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                record.get('recorded_at'),
                record.get('systolic'),
                record.get('diastolic'),
                record.get('glucose'),
                record.get('weight'),
                record.get('notes', 'Imported from Apple Health')
            ))
            imported_count += 1
        except Exception as e:
            print(f"Error importing record: {e}")
            continue
    
    conn.commit()
    conn.close()
    
    return jsonify({
        'imported': imported_count,
        'message': f'Successfully imported {imported_count} vital sign records'
    }), 201

@app.route('/api/vital-signs/export-apple-health', methods=['GET'])
def export_vital_signs_apple_health():
    import csv
    from io import StringIO
    from datetime import datetime
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM vital_signs ORDER BY recorded_at ASC')
    signs = cursor.fetchall()
    conn.close()
    
    output = StringIO()
    writer = csv.writer(output)
    
    writer.writerow(['type', 'sourceName', 'sourceVersion', 'unit', 'creationDate', 'startDate', 'endDate', 'value'])
    
    for sign in signs:
        recorded_at = sign['recorded_at']
        creation_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S %z')
        
        if sign['systolic']:
            writer.writerow([
                'HKQuantityTypeIdentifierBloodPressureSystolic',
                'Patient Care Tracker',
                '1.0',
                'mmHg',
                creation_date,
                recorded_at,
                recorded_at,
                sign['systolic']
            ])
        
        if sign['diastolic']:
            writer.writerow([
                'HKQuantityTypeIdentifierBloodPressureDiastolic',
                'Patient Care Tracker',
                '1.0',
                'mmHg',
                creation_date,
                recorded_at,
                recorded_at,
                sign['diastolic']
            ])
        
        if sign['glucose']:
            writer.writerow([
                'HKQuantityTypeIdentifierBloodGlucose',
                'Patient Care Tracker',
                '1.0',
                'mg/dL',
                creation_date,
                recorded_at,
                recorded_at,
                sign['glucose']
            ])
        
        if sign['weight']:
            weight_kg = round(sign['weight'] / 2.20462, 2)
            writer.writerow([
                'HKQuantityTypeIdentifierBodyMass',
                'Patient Care Tracker',
                '1.0',
                'kg',
                creation_date,
                recorded_at,
                recorded_at,
                weight_kg
            ])
    
    csv_content = output.getvalue()
    output.close()
    
    from flask import Response
    return Response(
        csv_content,
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=vital_signs_apple_health_export.csv'}
    )

@app.route('/api/sync-to-google-calendar', methods=['POST'])
def sync_to_google_calendar():
    import subprocess
    try:
        result = subprocess.run(
            ['node', 'sync-to-google-calendar.js'],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            try:
                output_lines = result.stdout.strip().split('\n')
                last_line = output_lines[-1]
                sync_results = json.loads(last_line)
                return jsonify({
                    'success': True,
                    'message': 'Successfully synced to Google Calendar!',
                    'results': sync_results
                })
            except (json.JSONDecodeError, IndexError):
                return jsonify({
                    'success': True,
                    'message': 'Sync completed!',
                    'output': result.stdout
                })
        else:
            return jsonify({
                'success': False,
                'message': 'Sync failed',
                'error': result.stderr
            }), 500
    except subprocess.TimeoutExpired:
        return jsonify({
            'success': False,
            'message': 'Sync timeout - operation took too long'
        }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        }), 500

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
