const API_URL = '/api';

let notificationCheckInterval = null;

function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const timeString = `${hours}:${minutes}:${seconds}`;
    document.getElementById('liveClock').textContent = timeString;
}

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    loadDashboard();
    checkNotificationPermission();
    startNotificationChecker();
    updateClock();
    setInterval(updateClock, 1000);
});

function initNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const menuToggle = document.getElementById('menuToggle');
    const navMenu = document.getElementById('navMenu');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.dataset.page;
            showPage(page);
            
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            
            navMenu.classList.remove('active');
        });
    });
    
    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });
}

function showPage(pageName) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    const targetPage = document.getElementById(pageName);
    if (targetPage) {
        targetPage.classList.add('active');
        
        if (pageName === 'dashboard') loadDashboard();
        else if (pageName === 'medications') loadMedications();
        else if (pageName === 'appointments') loadAppointments();
        else if (pageName === 'exercises') loadExercises();
        else if (pageName === 'calendar') loadCalendar();
        else if (pageName === 'vitalsigns') {
            clearVitalSignsForm();
            loadVitalSigns();
        }
    }
}

function showMessage(message, type = 'success') {
    const messageBox = document.getElementById('messageBox');
    messageBox.textContent = message;
    messageBox.className = `message-box ${type} show`;
    
    setTimeout(() => {
        messageBox.classList.remove('show');
    }, 3000);
}

function checkNotificationPermission() {
    const alert = document.getElementById('notificationAlert');
    const enabled = localStorage.getItem('inAppNotificationsEnabled');
    
    if (enabled === 'true') {
        alert.style.display = 'none';
    } else {
        alert.style.display = 'block';
    }
}

async function requestNotificationPermission() {
    console.log('✅ Enabling in-app notifications...');
    
    localStorage.setItem('inAppNotificationsEnabled', 'true');
    showMessage('✅ Reminders enabled! You\'ll get visual and audio alerts for medications and appointments.');
    document.getElementById('notificationAlert').style.display = 'none';
    
    showInAppNotification('💊 Reminders Enabled!', 'You will now receive in-app alerts for medications and appointments', '✅');
}

function startNotificationChecker() {
    if (notificationCheckInterval) {
        clearInterval(notificationCheckInterval);
    }
    
    checkForReminders();
    
    notificationCheckInterval = setInterval(() => {
        checkForReminders();
    }, 60000);
}

async function checkForReminders() {
    const enabled = localStorage.getItem('inAppNotificationsEnabled');
    console.log('Checking for reminders... Enabled:', enabled);
    
    if (enabled !== 'true') {
        console.log('In-app notifications not enabled yet');
        return;
    }
    
    try {
        await checkMedicationReminders();
        await checkAppointmentReminders();
        await checkPostponedReminders();
    } catch (error) {
        console.error('Error checking reminders:', error);
    }
}

async function checkMedicationReminders() {
    try {
        const response = await fetch(`${API_URL}/medications`);
        const medications = await response.json();
        const now = new Date();
        
        console.log(`Checking ${medications.length} medications at ${now.toLocaleTimeString()}`);
        
        for (const med of medications) {
            const todayStart = new Date(now);
            todayStart.setHours(0, 0, 0, 0);
            
            if (med.start_date) {
                const startDate = new Date(med.start_date);
                startDate.setHours(0, 0, 0, 0);
                if (startDate > todayStart) {
                    console.log(`Skipping ${med.name} - hasn't started yet (start: ${startDate}, today: ${todayStart})`);
                    continue;
                }
            }
            if (med.end_date) {
                const endDate = new Date(med.end_date);
                endDate.setHours(23, 59, 59, 999);
                if (endDate < now) {
                    console.log(`Skipping ${med.name} - already ended`);
                    continue;
                }
            }
            
            const timeSlots = JSON.parse(med.time_slots);
            console.log(`Checking medication: ${med.name}, time slots:`, timeSlots);
            
            const logsResponse = await fetch(`${API_URL}/medications/${med.id}/logs`);
            const logs = await logsResponse.json();
            
            const todayStr = now.toISOString().split('T')[0];
            
            for (const timeStr of timeSlots) {
                let hours, minutes;
                if (timeStr.includes(':')) {
                    [hours, minutes] = timeStr.split(':');
                } else {
                    hours = timeStr.substring(0, 2);
                    minutes = timeStr.substring(2, 4);
                }
                
                const scheduledTime = new Date();
                scheduledTime.setHours(parseInt(hours), parseInt(minutes), 0, 0);
                
                const timeDiff = scheduledTime - now;
                const minutesDiff = Math.floor(timeDiff / 1000 / 60);
                
                console.log(`${med.name} at ${hours}:${minutes}: ${minutesDiff} minutes away`);
                
                const alreadyTaken = logs.some(log => {
                    const logDate = new Date(log.taken_at).toISOString().split('T')[0];
                    return logDate === todayStr && log.scheduled_time === timeStr && log.status === 'taken';
                });
                
                console.log(`Already taken today: ${alreadyTaken}`);
                
                if (minutesDiff >= 0 && minutesDiff <= 1) {
                    console.log(`🔔 TIME TO NOTIFY! ${med.name} at ${timeStr}`);
                    if (!alreadyTaken) {
                        showMedicationNotification(med, timeStr);
                    }
                } else if (minutesDiff >= -15 && minutesDiff <= -14) {
                    console.log(`⚠️ OVERDUE NOTIFICATION! ${med.name} at ${timeStr}`);
                    if (!alreadyTaken) {
                        showOverdueNotification(med, timeStr);
                    }
                }
            }
        }
    } catch (error) {
        console.error('Error checking medication reminders:', error);
    }
}

async function checkAppointmentReminders() {
    try {
        const response = await fetch(`${API_URL}/appointments`);
        const appointments = await response.json();
        const now = new Date();
        
        for (const appt of appointments) {
            if (appt.completed) {
                continue;
            }
            
            const apptDateTime = new Date(`${appt.date}T${appt.time}`);
            const timeDiff = apptDateTime - now;
            const minutesDiff = Math.floor(timeDiff / 1000 / 60);
            const hoursDiff = Math.floor(timeDiff / 1000 / 60 / 60);
            
            if (minutesDiff === 60) {
                showAppointmentNotification(appt, '1 hour');
            } else if (hoursDiff === 24) {
                showAppointmentNotification(appt, '24 hours');
            }
        }
    } catch (error) {
        console.error('Error checking appointment reminders:', error);
    }
}

function showMedicationNotification(medication, scheduledTime) {
    console.log('🔔 SHOWING NOTIFICATION:', medication.name, scheduledTime);
    
    const title = '💊 Time to Take Your Medication!';
    const message = `${medication.name} (${medication.dosage}) - Scheduled for ${scheduledTime}`;
    
    const actions = [
        {
            label: '✓ Take',
            class: 'btn-take',
            onClick: async (e) => {
                e.stopPropagation();
                await markMedicationFromNotification(medication.id, scheduledTime, 'taken');
                closeInAppNotification();
            }
        },
        {
            label: '⊘ Skip',
            class: 'btn-skip',
            onClick: async (e) => {
                e.stopPropagation();
                await markMedicationFromNotification(medication.id, scheduledTime, 'skipped');
                closeInAppNotification();
            }
        },
        {
            label: '↶ Untake Dose',
            class: 'btn-untake',
            onClick: async (e) => {
                e.stopPropagation();
                await untakeMedicationDose(medication.id, scheduledTime);
                closeInAppNotification();
            }
        },
        {
            label: '⏰ Postpone',
            class: 'btn-postpone',
            onClick: (e) => {
                e.stopPropagation();
                showPostponeOptions(medication, scheduledTime);
            }
        }
    ];
    
    showInAppNotification(title, message, '💊', null, actions, true);
}

function showOverdueNotification(medication, scheduledTime) {
    console.log('⚠️ SHOWING OVERDUE NOTIFICATION:', medication.name, scheduledTime);
    
    const title = '⚠️ Missed Medication!';
    const message = `You missed ${medication.name} (${medication.dosage}) scheduled for ${scheduledTime}`;
    
    const actions = [
        {
            label: '✓ Take Now',
            class: 'btn-take',
            onClick: async (e) => {
                e.stopPropagation();
                await markMedicationFromNotification(medication.id, scheduledTime, 'taken');
                closeInAppNotification();
            }
        },
        {
            label: '✗ Mark Missed',
            class: 'btn-missed',
            onClick: async (e) => {
                e.stopPropagation();
                await markMedicationFromNotification(medication.id, scheduledTime, 'missed');
                closeInAppNotification();
            }
        },
        {
            label: '↶ Untake Dose',
            class: 'btn-untake',
            onClick: async (e) => {
                e.stopPropagation();
                await untakeMedicationDose(medication.id, scheduledTime);
                closeInAppNotification();
            }
        },
        {
            label: '⏰ Postpone',
            class: 'btn-postpone',
            onClick: (e) => {
                e.stopPropagation();
                showPostponeOptions(medication, scheduledTime);
            }
        }
    ];
    
    showInAppNotification(title, message, '⚠️', null, actions, true);
}

function showAppointmentNotification(appointment, timeUntil) {
    console.log('🏥 SHOWING APPOINTMENT NOTIFICATION:', appointment.doctor, timeUntil);
    
    const title = '🏥 Appointment Reminder!';
    const message = `Appointment with ${appointment.doctor} in ${timeUntil} - ${appointment.date} at ${appointment.time}`;
    
    showInAppNotification(title, message, '🏥', () => {
        showPage('appointments');
    });
}

function showPostponeOptions(medication, scheduledTime) {
    const title = '⏰ Postpone Medication';
    const message = `How long would you like to postpone ${medication.name}?`;
    
    const postponeOptions = [
        { label: '5 minutes', minutes: 5 },
        { label: '15 minutes', minutes: 15 },
        { label: '30 minutes', minutes: 30 },
        { label: '1 hour', minutes: 60 },
        { label: '2 hours', minutes: 120 },
        { label: '3 hours', minutes: 180 },
        { label: '4 hours', minutes: 240 },
        { label: '5 hours', minutes: 300 }
    ];
    
    const actions = postponeOptions.map(option => ({
        label: option.label,
        class: 'btn-postpone-option',
        onClick: (e) => {
            e.stopPropagation();
            postponeMedication(medication, scheduledTime, option.minutes);
            closeInAppNotification();
        }
    }));
    
    showInAppNotification(title, message, '⏰', null, actions);
}

function postponeMedication(medication, scheduledTime, minutes) {
    const postponedReminders = JSON.parse(localStorage.getItem('postponedReminders') || '[]');
    
    const postponedTime = new Date();
    postponedTime.setMinutes(postponedTime.getMinutes() + minutes);
    
    postponedReminders.push({
        medication: medication,
        originalScheduledTime: scheduledTime,
        postponedUntil: postponedTime.toISOString(),
        id: `${medication.id}_${scheduledTime}_${Date.now()}`
    });
    
    localStorage.setItem('postponedReminders', JSON.stringify(postponedReminders));
    
    showMessage(`Medication postponed for ${minutes} minutes`, 'success');
    console.log(`Postponed ${medication.name} for ${minutes} minutes until ${postponedTime.toLocaleTimeString()}`);
}

async function checkPostponedReminders() {
    try {
        const postponedReminders = JSON.parse(localStorage.getItem('postponedReminders') || '[]');
        const now = new Date();
        const remainingReminders = [];
        
        for (const reminder of postponedReminders) {
            const postponedTime = new Date(reminder.postponedUntil);
            
            if (now >= postponedTime) {
                console.log(`⏰ POSTPONED REMINDER DUE: ${reminder.medication.name}`);
                showMedicationNotification(reminder.medication, reminder.originalScheduledTime);
            } else {
                remainingReminders.push(reminder);
            }
        }
        
        localStorage.setItem('postponedReminders', JSON.stringify(remainingReminders));
    } catch (error) {
        console.error('Error checking postponed reminders:', error);
    }
}

async function markMedicationFromNotification(medicationId, scheduledTime, status) {
    try {
        const response = await fetch(`${API_URL}/medications/${medicationId}/log`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                scheduled_time: scheduledTime,
                status: status
            })
        });
        
        if (response.ok) {
            showMessage(`Medication marked as ${status}`, 'success');
            loadDashboard();
            const medicationsPage = document.getElementById('medications');
            if (medicationsPage && medicationsPage.classList.contains('active')) {
                loadMedications();
            }
        } else {
            showMessage('Error logging medication', 'error');
        }
    } catch (error) {
        console.error('Error marking medication:', error);
        showMessage('Error logging medication', 'error');
    }
}

async function untakeMedicationDose(medicationId, scheduledTime) {
    try {
        const logsResponse = await fetch(`${API_URL}/medications/${medicationId}/logs`);
        if (!logsResponse.ok) {
            showMessage('Error fetching medication logs', 'error');
            return;
        }
        
        const logs = await logsResponse.json();
        
        const logToDelete = logs.find(log => 
            log.scheduled_time === scheduledTime && 
            (log.status === 'taken' || log.status === 'skipped' || log.status === 'missed')
        );
        
        if (logToDelete) {
            const deleteResponse = await fetch(`${API_URL}/medication-logs/${logToDelete.id}`, {
                method: 'DELETE'
            });
            
            if (deleteResponse.ok) {
                showMessage('Medication dose untaken successfully', 'success');
                loadDashboard();
                const medicationsPage = document.getElementById('medications');
                if (medicationsPage && medicationsPage.classList.contains('active')) {
                    loadMedications();
                }
            } else {
                showMessage('Error untaking medication', 'error');
            }
        } else {
            showMessage('No dose found to untake for this time', 'info');
        }
    } catch (error) {
        console.error('Error untaking medication:', error);
        showMessage('Error untaking medication', 'error');
    }
}

let notificationTimeout = null;

function showInAppNotification(title, message, icon = '🔔', onClick = null, actions = null, waitForAction = false) {
    const notification = document.getElementById('inAppNotification');
    const notificationIcon = document.getElementById('notificationIcon');
    const notificationTitle = document.getElementById('notificationTitle');
    const notificationMessage = document.getElementById('notificationMessage');
    const notificationActionsContainer = document.getElementById('notificationActions');
    const sound = document.getElementById('notificationSound');
    
    notificationTitle.textContent = title;
    notificationMessage.textContent = message;
    notificationIcon.textContent = icon;
    
    notificationActionsContainer.innerHTML = '';
    
    if (actions && actions.length > 0) {
        actions.forEach(action => {
            const button = document.createElement('button');
            button.textContent = action.label;
            button.className = `notification-action-btn ${action.class}`;
            button.onclick = action.onClick;
            notificationActionsContainer.appendChild(button);
        });
        
        notification.onclick = null;
    } else {
        notification.onclick = () => {
            if (onClick) {
                onClick();
            }
            closeInAppNotification();
        };
    }
    
    notification.classList.add('show');
    
    if (sound) {
        sound.play().catch(err => console.log('Could not play sound:', err));
    }
    
    if (notificationTimeout) {
        clearTimeout(notificationTimeout);
    }
    
    if (!waitForAction) {
        notificationTimeout = setTimeout(() => {
            closeInAppNotification();
        }, 10000);
    }
}

function closeInAppNotification() {
    const notification = document.getElementById('inAppNotification');
    notification.classList.remove('show');
    
    if (notificationTimeout) {
        clearTimeout(notificationTimeout);
        notificationTimeout = null;
    }
}

async function loadDashboard() {
    try {
        const response = await fetch(`${API_URL}/dashboard`);
        const data = await response.json();
        
        document.getElementById('medsTakenStat').textContent = 
            `${data.medications_taken_today}/${data.total_medications}`;
        document.getElementById('apptsToday').textContent = data.appointments_today;
        document.getElementById('exercisesToday').textContent = data.exercises_completed_today;
    } catch (error) {
        console.error('Error loading dashboard:', error);
        showMessage('Error loading dashboard data', 'error');
    }
}

function showMedicationForm() {
    document.getElementById('medicationForm').style.display = 'block';
}

function hideMedicationForm() {
    document.getElementById('medicationForm').style.display = 'none';
    document.getElementById('medForm').reset();
    document.getElementById('intervalGroup').style.display = 'none';
}

function toggleIntervalField() {
    const frequency = document.getElementById('medFrequency').value;
    const intervalGroup = document.getElementById('intervalGroup');
    
    if (frequency === 'Every X hours') {
        intervalGroup.style.display = 'block';
    } else {
        intervalGroup.style.display = 'none';
    }
}

async function saveMedication(event) {
    event.preventDefault();
    
    const name = document.getElementById('medName').value;
    const dosage = document.getElementById('medDosage').value;
    let frequency = document.getElementById('medFrequency').value;
    const timesStr = document.getElementById('medTimes').value;
    const time_slots = timesStr.split(',').map(t => t.trim());
    const start_date = document.getElementById('medStartDate').value || null;
    const end_date = document.getElementById('medEndDate').value || null;
    
    if (frequency === 'Every X hours') {
        const interval = document.getElementById('medInterval').value;
        frequency = `Every ${interval} hours`;
    }
    
    try {
        const response = await fetch(`${API_URL}/medications`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, dosage, frequency, time_slots, start_date, end_date })
        });
        
        if (response.ok) {
            showMessage('Medication added successfully!');
            hideMedicationForm();
            loadMedications();
        } else {
            showMessage('Error adding medication', 'error');
        }
    } catch (error) {
        console.error('Error saving medication:', error);
        showMessage('Error saving medication', 'error');
    }
}

async function loadMedications() {
    try {
        const response = await fetch(`${API_URL}/medications`);
        const medications = await response.json();
        
        const listContainer = document.getElementById('medicationList');
        listContainer.innerHTML = '';
        
        if (medications.length === 0) {
            listContainer.innerHTML = '<p style="text-align: center; color: var(--dark-gray); padding: 2rem;">No medications added yet. Click "Add New Medication" to get started.</p>';
            return;
        }
        
        for (const med of medications) {
            const times = JSON.parse(med.time_slots);
            const logsResponse = await fetch(`${API_URL}/medications/${med.id}/logs`);
            const logs = await logsResponse.json();
            
            const card = document.createElement('div');
            card.className = 'item-card';
            
            let timesHTML = times.map(time => {
                const logForTime = logs.find(log => log.scheduled_time === time && log.status === 'taken');
                const status = logForTime ? 'taken' : 'pending';
                const badgeClass = status === 'taken' ? 'badge-success' : 'badge-warning';
                
                return `
                    <div style="display: inline-block; margin-right: 1rem; margin-bottom: 0.5rem;">
                        <span>${time}</span>
                        <button class="btn btn-sm ${status === 'taken' ? 'btn-secondary' : 'btn-success'}" 
                                onclick="logMedication(${med.id}, '${time}')"
                                ${status === 'taken' ? 'disabled' : ''}>
                            ${status === 'taken' ? '✓ Taken' : 'Mark Taken'}
                        </button>
                    </div>
                `;
            }).join('');
            
            let treatmentPeriod = '';
            if (med.start_date || med.end_date) {
                treatmentPeriod = '<p><strong>Treatment Period:</strong> ';
                if (med.start_date) {
                    const startDate = new Date(med.start_date);
                    treatmentPeriod += `From ${startDate.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}`;
                }
                if (med.end_date) {
                    const endDate = new Date(med.end_date);
                    treatmentPeriod += ` to ${endDate.toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' })}`;
                }
                treatmentPeriod += '</p>';
            }
            
            let trackingInfo = '';
            if (med.last_taken) {
                const lastTaken = new Date(med.last_taken);
                trackingInfo += `<p><strong>Last Taken:</strong> ${lastTaken.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</p>`;
            }
            if (med.next_dose) {
                const nextDose = new Date(med.next_dose);
                const now = new Date();
                const isOverdue = nextDose < now;
                trackingInfo += `<p><strong>Next Dose:</strong> <span style="color: ${isOverdue ? 'var(--error-red)' : 'var(--success-green)'}; font-weight: 600;">${nextDose.toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span> ${isOverdue ? '(Overdue)' : ''}</p>`;
            }
            
            card.innerHTML = `
                <div class="item-header">
                    <div>
                        <div class="item-title">${med.name}</div>
                        <div class="item-details">
                            <p><strong>Dosage:</strong> ${med.dosage}</p>
                            <p><strong>Frequency:</strong> ${med.frequency}</p>
                            ${treatmentPeriod}
                            ${trackingInfo}
                        </div>
                    </div>
                    <div class="item-actions">
                        <button class="btn btn-primary btn-sm" onclick='editMedication(${JSON.stringify(med)})'>Edit</button>
                        <button class="btn btn-danger btn-sm" onclick="deleteMedication(${med.id})">Delete</button>
                    </div>
                </div>
                <div style="margin-top: 1rem;">
                    <strong>Scheduled Times:</strong><br>
                    ${timesHTML}
                </div>
            `;
            
            listContainer.appendChild(card);
        }
    } catch (error) {
        console.error('Error loading medications:', error);
        showMessage('Error loading medications', 'error');
    }
}

async function logMedication(medId, scheduledTime) {
    try {
        const response = await fetch(`${API_URL}/medications/${medId}/log`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ scheduled_time: scheduledTime, status: 'taken' })
        });
        
        if (response.ok) {
            showMessage('Medication marked as taken!');
            loadMedications();
            loadDashboard();
        } else {
            showMessage('Error logging medication', 'error');
        }
    } catch (error) {
        console.error('Error logging medication:', error);
        showMessage('Error logging medication', 'error');
    }
}

async function deleteMedication(id) {
    if (!confirm('Are you sure you want to delete this medication?')) return;
    
    try {
        const response = await fetch(`${API_URL}/medications/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showMessage('Medication deleted successfully!');
            loadMedications();
            loadDashboard();
        } else {
            showMessage('Error deleting medication', 'error');
        }
    } catch (error) {
        console.error('Error deleting medication:', error);
        showMessage('Error deleting medication', 'error');
    }
}

function editMedication(med) {
    document.getElementById('editMedId').value = med.id;
    document.getElementById('editMedName').value = med.name;
    document.getElementById('editMedDosage').value = med.dosage;
    
    let frequency = med.frequency;
    if (frequency.includes('hour') && !frequency.includes('Once') && !frequency.includes('Twice') && !frequency.includes('Three')) {
        document.getElementById('editMedFrequency').value = 'Every X hours';
        const hours = parseInt(frequency.match(/\d+/));
        document.getElementById('editMedInterval').value = hours;
        document.getElementById('editIntervalGroup').style.display = 'block';
    } else {
        document.getElementById('editMedFrequency').value = frequency;
        document.getElementById('editIntervalGroup').style.display = 'none';
    }
    
    const times = JSON.parse(med.time_slots);
    document.getElementById('editMedTimes').value = times.join(', ');
    
    if (med.start_date) {
        document.getElementById('editMedStartDate').value = med.start_date.slice(0, 16);
    } else {
        document.getElementById('editMedStartDate').value = '';
    }
    
    if (med.end_date) {
        document.getElementById('editMedEndDate').value = med.end_date.slice(0, 16);
    } else {
        document.getElementById('editMedEndDate').value = '';
    }
    
    document.getElementById('editMedicationModal').style.display = 'block';
}

function toggleEditIntervalField() {
    const frequency = document.getElementById('editMedFrequency').value;
    const intervalGroup = document.getElementById('editIntervalGroup');
    
    if (frequency === 'Every X hours') {
        intervalGroup.style.display = 'block';
    } else {
        intervalGroup.style.display = 'none';
    }
}

function hideEditMedicationModal() {
    document.getElementById('editMedicationModal').style.display = 'none';
}

async function updateMedication(event) {
    event.preventDefault();
    
    const id = document.getElementById('editMedId').value;
    const name = document.getElementById('editMedName').value;
    const dosage = document.getElementById('editMedDosage').value;
    let frequency = document.getElementById('editMedFrequency').value;
    const timesStr = document.getElementById('editMedTimes').value;
    const time_slots = timesStr.split(',').map(t => t.trim());
    const start_date = document.getElementById('editMedStartDate').value || null;
    const end_date = document.getElementById('editMedEndDate').value || null;
    
    if (frequency === 'Every X hours') {
        const interval = document.getElementById('editMedInterval').value;
        frequency = `Every ${interval} hours`;
    }
    
    try {
        const response = await fetch(`${API_URL}/medications/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, dosage, frequency, time_slots, start_date, end_date })
        });
        
        if (response.ok) {
            showMessage('Medication updated successfully!');
            hideEditMedicationModal();
            loadMedications();
            loadDashboard();
        } else {
            showMessage('Error updating medication', 'error');
        }
    } catch (error) {
        console.error('Error updating medication:', error);
        showMessage('Error updating medication', 'error');
    }
}

function showAppointmentForm() {
    document.getElementById('appointmentForm').style.display = 'block';
}

function hideAppointmentForm() {
    document.getElementById('appointmentForm').style.display = 'none';
    document.getElementById('apptForm').reset();
}

async function saveAppointment(event) {
    event.preventDefault();
    
    const appointment = {
        date: document.getElementById('apptDate').value,
        time: document.getElementById('apptTime').value,
        doctor_name: document.getElementById('apptDoctor').value,
        facility: document.getElementById('apptFacility').value,
        purpose: document.getElementById('apptPurpose').value,
        notes: document.getElementById('apptNotes').value
    };
    
    try {
        const response = await fetch(`${API_URL}/appointments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(appointment)
        });
        
        if (response.ok) {
            showMessage('Appointment added successfully!');
            hideAppointmentForm();
            loadAppointments();
        } else {
            showMessage('Error adding appointment', 'error');
        }
    } catch (error) {
        console.error('Error saving appointment:', error);
        showMessage('Error saving appointment', 'error');
    }
}

async function loadAppointments() {
    try {
        const response = await fetch(`${API_URL}/appointments`);
        const appointments = await response.json();
        
        const listContainer = document.getElementById('appointmentList');
        listContainer.innerHTML = '';
        
        if (appointments.length === 0) {
            listContainer.innerHTML = '<p style="text-align: center; color: var(--dark-gray); padding: 2rem;">No appointments scheduled. Click "Add New Appointment" to get started.</p>';
            return;
        }
        
        appointments.forEach(appt => {
            const apptDate = new Date(appt.date + 'T' + appt.time);
            const isCompleted = appt.completed;
            const isPast = apptDate < new Date();
            
            let cardClass = 'item-card';
            if (isCompleted) cardClass += ' completed';
            else if (isPast) cardClass += ' missed';
            else cardClass += ' pending';
            
            const card = document.createElement('div');
            card.className = cardClass;
            
            card.innerHTML = `
                <div class="item-header">
                    <div>
                        <div class="item-title">${appt.doctor_name}</div>
                        <div class="item-details">
                            <p><strong>Date:</strong> ${new Date(appt.date).toLocaleDateString()}</p>
                            <p><strong>Time:</strong> ${appt.time}</p>
                            ${appt.facility ? `<p><strong>Facility:</strong> ${appt.facility}</p>` : ''}
                            ${appt.purpose ? `<p><strong>Purpose:</strong> ${appt.purpose}</p>` : ''}
                            ${appt.notes ? `<p><strong>Notes:</strong> ${appt.notes}</p>` : ''}
                        </div>
                    </div>
                    <div class="item-actions">
                        <button class="btn btn-primary btn-sm" onclick='editAppointment(${JSON.stringify(appt).replace(/'/g, "&apos;")})'>Edit</button>
                        ${!isCompleted ? `<button class="btn btn-success btn-sm" onclick="markAppointmentComplete(${appt.id})">Complete</button>` : ''}
                        <button class="btn btn-danger btn-sm" onclick="deleteAppointment(${appt.id})">Delete</button>
                    </div>
                </div>
                ${isCompleted ? '<span class="badge badge-success">Completed</span>' : ''}
            `;
            
            listContainer.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading appointments:', error);
        showMessage('Error loading appointments', 'error');
    }
}

async function markAppointmentComplete(id) {
    try {
        const response = await fetch(`${API_URL}/appointments/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed: 1 })
        });
        
        if (response.ok) {
            showMessage('Appointment marked as completed!');
            loadAppointments();
            loadDashboard();
        } else {
            showMessage('Error updating appointment', 'error');
        }
    } catch (error) {
        console.error('Error updating appointment:', error);
        showMessage('Error updating appointment', 'error');
    }
}

async function deleteAppointment(id) {
    if (!confirm('Are you sure you want to delete this appointment?')) return;
    
    try {
        const response = await fetch(`${API_URL}/appointments/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showMessage('Appointment deleted successfully!');
            loadAppointments();
            loadDashboard();
        } else {
            showMessage('Error deleting appointment', 'error');
        }
    } catch (error) {
        console.error('Error deleting appointment:', error);
        showMessage('Error deleting appointment', 'error');
    }
}

function editAppointment(appt) {
    document.getElementById('editApptId').value = appt.id;
    document.getElementById('editApptDate').value = appt.date;
    document.getElementById('editApptTime').value = appt.time;
    document.getElementById('editApptDoctor').value = appt.doctor_name || appt.name || '';
    document.getElementById('editApptFacility').value = appt.facility || '';
    document.getElementById('editApptPurpose').value = appt.purpose || '';
    document.getElementById('editApptNotes').value = appt.notes || '';
    document.getElementById('editApptCompleted').checked = appt.completed === 1;
    document.getElementById('editAppointmentModal').style.display = 'block';
}

function hideEditAppointmentModal() {
    document.getElementById('editAppointmentModal').style.display = 'none';
}

async function updateAppointment(event) {
    event.preventDefault();
    
    const id = document.getElementById('editApptId').value;
    const appointment = {
        date: document.getElementById('editApptDate').value,
        time: document.getElementById('editApptTime').value,
        doctor_name: document.getElementById('editApptDoctor').value,
        facility: document.getElementById('editApptFacility').value,
        purpose: document.getElementById('editApptPurpose').value,
        notes: document.getElementById('editApptNotes').value,
        completed: document.getElementById('editApptCompleted').checked ? 1 : 0
    };
    
    try {
        const response = await fetch(`${API_URL}/appointments/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(appointment)
        });
        
        if (response.ok) {
            showMessage('Appointment updated successfully!');
            hideEditAppointmentModal();
            loadAppointments();
            loadDashboard();
        } else {
            showMessage('Error updating appointment', 'error');
        }
    } catch (error) {
        console.error('Error updating appointment:', error);
        showMessage('Error updating appointment', 'error');
    }
}

function editMedicationLog(medLog) {
    document.getElementById('editMedLogId').value = medLog.id;
    document.getElementById('editMedLogTime').value = medLog.scheduled_time;
    document.getElementById('editMedLogStatus').value = medLog.status;
    document.getElementById('editMedLogModal').style.display = 'block';
}

function hideEditMedLogModal() {
    document.getElementById('editMedLogModal').style.display = 'none';
}

async function updateMedicationLog(event) {
    event.preventDefault();
    
    const id = document.getElementById('editMedLogId').value;
    const medLog = {
        scheduled_time: document.getElementById('editMedLogTime').value,
        status: document.getElementById('editMedLogStatus').value
    };
    
    try {
        const response = await fetch(`${API_URL}/medication-logs/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(medLog)
        });
        
        if (response.ok) {
            showMessage('Medication log updated successfully!');
            hideEditMedLogModal();
            loadMedications();
            loadDashboard();
            loadCalendar();
        } else {
            showMessage('Error updating medication log', 'error');
        }
    } catch (error) {
        console.error('Error updating medication log:', error);
        showMessage('Error updating medication log', 'error');
    }
}

function editExerciseLog(exLog) {
    document.getElementById('editExLogId').value = exLog.id;
    document.getElementById('editExLogDuration').value = exLog.duration || '';
    document.getElementById('editExLogNotes').value = exLog.notes || '';
    document.getElementById('editExLogModal').style.display = 'block';
}

function hideEditExLogModal() {
    document.getElementById('editExLogModal').style.display = 'none';
}

async function updateExerciseLog(event) {
    event.preventDefault();
    
    const id = document.getElementById('editExLogId').value;
    const exLog = {
        duration_actual: document.getElementById('editExLogDuration').value || null,
        notes: document.getElementById('editExLogNotes').value
    };
    
    try {
        const response = await fetch(`${API_URL}/exercise-logs/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(exLog)
        });
        
        if (response.ok) {
            showMessage('Exercise log updated successfully!');
            hideEditExLogModal();
            loadCalendar();
        } else {
            showMessage('Error updating exercise log', 'error');
        }
    } catch (error) {
        console.error('Error updating exercise log:', error);
        showMessage('Error updating exercise log', 'error');
    }
}

function showExerciseForm() {
    document.getElementById('exerciseForm').style.display = 'block';
}

function hideExerciseForm() {
    document.getElementById('exerciseForm').style.display = 'none';
    document.getElementById('exForm').reset();
}

async function saveExercise(event) {
    event.preventDefault();
    
    const exercise = {
        name: document.getElementById('exName').value,
        description: document.getElementById('exDescription').value,
        duration_minutes: document.getElementById('exDuration').value || null,
        sets: document.getElementById('exSets').value || null,
        reps: document.getElementById('exReps').value || null
    };
    
    try {
        const response = await fetch(`${API_URL}/exercises`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(exercise)
        });
        
        if (response.ok) {
            showMessage('Exercise added successfully!');
            hideExerciseForm();
            loadExercises();
        } else {
            showMessage('Error adding exercise', 'error');
        }
    } catch (error) {
        console.error('Error saving exercise:', error);
        showMessage('Error saving exercise', 'error');
    }
}

async function loadExercises() {
    try {
        const response = await fetch(`${API_URL}/exercises`);
        const exercises = await response.json();
        
        const listContainer = document.getElementById('exerciseList');
        listContainer.innerHTML = '';
        
        if (exercises.length === 0) {
            listContainer.innerHTML = '<p style="text-align: center; color: var(--dark-gray); padding: 2rem;">No exercises added yet. Click "Add New Exercise" to get started.</p>';
            return;
        }
        
        exercises.forEach(ex => {
            const card = document.createElement('div');
            card.className = 'item-card';
            
            let detailsHTML = '';
            if (ex.duration_minutes) detailsHTML += `<p><strong>Duration:</strong> ${ex.duration_minutes} minutes</p>`;
            if (ex.sets) detailsHTML += `<p><strong>Sets:</strong> ${ex.sets}</p>`;
            if (ex.reps) detailsHTML += `<p><strong>Reps:</strong> ${ex.reps}</p>`;
            
            card.innerHTML = `
                <div class="item-header">
                    <div>
                        <div class="item-title">${ex.name}</div>
                        <div class="item-details">
                            ${ex.description ? `<p>${ex.description}</p>` : ''}
                            ${detailsHTML}
                        </div>
                    </div>
                    <div class="item-actions">
                        <button class="btn btn-success btn-sm" onclick="logExercise(${ex.id})">Log Completed</button>
                    </div>
                </div>
            `;
            
            listContainer.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading exercises:', error);
        showMessage('Error loading exercises', 'error');
    }
}

async function logExercise(exerciseId) {
    const duration = prompt('How many minutes did you exercise?');
    const notes = prompt('Any notes? (optional)');
    
    try {
        const response = await fetch(`${API_URL}/exercises/${exerciseId}/log`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                duration_actual: duration ? parseInt(duration) : null,
                notes: notes || ''
            })
        });
        
        if (response.ok) {
            showMessage('Exercise logged successfully!');
            loadDashboard();
        } else {
            showMessage('Error logging exercise', 'error');
        }
    } catch (error) {
        console.error('Error logging exercise:', error);
        showMessage('Error logging exercise', 'error');
    }
}

let allActivities = [];

async function loadCalendar() {
    const monthInput = document.getElementById('calendarMonth');
    const searchInput = document.getElementById('calendarSearch');
    
    if (!monthInput.value) {
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        monthInput.value = `${year}-${month}`;
    }
    
    if (!monthInput.hasAttribute('data-initialized')) {
        monthInput.addEventListener('change', filterCalendar);
        searchInput.addEventListener('input', filterCalendar);
        monthInput.setAttribute('data-initialized', 'true');
    }
    
    await fetchCalendarData();
}

async function fetchCalendarData() {
    try {
        const monthInput = document.getElementById('calendarMonth');
        const selectedMonth = monthInput.value;
        
        let url = `${API_URL}/calendar`;
        if (selectedMonth) {
            url += `?month=${selectedMonth}`;
        }
        
        const response = await fetch(url);
        allActivities = await response.json();
        
        filterCalendar();
    } catch (error) {
        console.error('Error loading calendar:', error);
        showMessage('Error loading calendar data', 'error');
    }
}

function filterCalendar() {
    const searchInput = document.getElementById('calendarSearch');
    const searchTerm = searchInput.value.toLowerCase();
    
    let filteredActivities = allActivities;
    
    if (searchTerm) {
        filteredActivities = allActivities.filter(activity => {
            const searchableText = [
                activity.name,
                activity.dosage,
                activity.facility,
                activity.purpose,
                activity.notes,
                activity.description,
                activity.type
            ].filter(Boolean).join(' ').toLowerCase();
            
            return searchableText.includes(searchTerm);
        });
    }
    
    displayCalendarActivities(filteredActivities);
}

function displayCalendarActivities(activities) {
    const listContainer = document.getElementById('calendarList');
    listContainer.innerHTML = '';
    
    const monthInput = document.getElementById('calendarMonth');
    const selectedMonth = monthInput.value;
    const [year, month] = selectedMonth.split('-');
    const monthName = new Date(year, month - 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    const summaryDiv = document.createElement('div');
    summaryDiv.style.marginBottom = '1.5rem';
    summaryDiv.style.padding = '1rem';
    summaryDiv.style.backgroundColor = '#f0f7ff';
    summaryDiv.style.borderRadius = '8px';
    summaryDiv.innerHTML = `
        <p style="margin: 0; color: var(--dark-gray); font-weight: 600;">
            ${monthName}: ${activities.length} activities
            (💊 ${activities.filter(a => a.type === 'medication').length} medications, 
            🏥 ${activities.filter(a => a.type === 'appointment').length} appointments, 
            🏃 ${activities.filter(a => a.type === 'exercise').length} exercises)
        </p>
    `;
    listContainer.appendChild(summaryDiv);
    
    const firstDay = new Date(year, month - 1, 1).getDay();
    const daysInMonth = new Date(year, month, 0).getDate();
    const activitiesByDate = {};
    
    activities.forEach(activity => {
        const activityDate = new Date(activity.datetime);
        const day = activityDate.getDate();
        if (!activitiesByDate[day]) {
            activitiesByDate[day] = [];
        }
        activitiesByDate[day].push(activity);
    });
    
    const calendarGrid = document.createElement('div');
    calendarGrid.className = 'calendar-grid';
    
    const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    weekdays.forEach(day => {
        const dayHeader = document.createElement('div');
        dayHeader.className = 'calendar-weekday';
        dayHeader.textContent = day;
        calendarGrid.appendChild(dayHeader);
    });
    
    for (let i = 0; i < firstDay; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.className = 'calendar-day empty';
        calendarGrid.appendChild(emptyDay);
    }
    
    for (let day = 1; day <= daysInMonth; day++) {
        const dayBox = document.createElement('div');
        dayBox.className = 'calendar-day';
        
        const today = new Date();
        if (day === today.getDate() && parseInt(month) === today.getMonth() + 1 && parseInt(year) === today.getFullYear()) {
            dayBox.classList.add('today');
        }
        
        const dayNumber = document.createElement('div');
        dayNumber.className = 'day-number';
        dayNumber.textContent = day;
        dayBox.appendChild(dayNumber);
        
        const dayActivities = activitiesByDate[day] || [];
        
        if (dayActivities.length > 0) {
            const activitiesContainer = document.createElement('div');
            activitiesContainer.className = 'day-activities';
            
            dayActivities.forEach(activity => {
                const activityItem = document.createElement('div');
                activityItem.className = 'activity-item';
                
                let icon = '';
                let className = '';
                let title = '';
                let time = '';
                
                if (activity.type === 'medication') {
                    icon = '💊';
                    className = activity.status === 'taken' ? 'completed' : 'missed';
                    time = activity.scheduled_time || '';
                    title = `${activity.name} - ${activity.status}`;
                    activityItem.style.cursor = 'pointer';
                    activityItem.title = 'Click to edit';
                    activityItem.onclick = () => editMedicationLog(activity);
                } else if (activity.type === 'appointment') {
                    icon = '🏥';
                    className = activity.completed ? 'completed' : 'pending';
                    time = activity.time || '';
                    title = `Dr. ${activity.name} - ${activity.completed ? 'Completed' : 'Scheduled'}`;
                    activityItem.style.cursor = 'pointer';
                    activityItem.title = 'Click to edit';
                    activityItem.onclick = () => editAppointment(activity);
                } else if (activity.type === 'exercise') {
                    icon = '🏃';
                    className = 'completed';
                    const datetime = new Date(activity.datetime);
                    time = datetime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                    title = activity.name;
                    activityItem.style.cursor = 'pointer';
                    activityItem.title = 'Click to edit';
                    activityItem.onclick = () => editExerciseLog(activity);
                }
                
                activityItem.className += ' ' + className;
                activityItem.innerHTML = `<span>${icon}</span> <span class="activity-text"><strong>${time}</strong> ${title}</span>`;
                activitiesContainer.appendChild(activityItem);
            });
            
            dayBox.appendChild(activitiesContainer);
        }
        
        calendarGrid.appendChild(dayBox);
    }
    
    listContainer.appendChild(calendarGrid);
}

async function syncToGoogleCalendar() {
    const button = event.target;
    const originalText = button.innerHTML;
    
    button.disabled = true;
    button.innerHTML = '⏳ Syncing...';
    
    try {
        const response = await fetch(`${API_URL}/sync-to-google-calendar`, {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            const medications = result.results?.medications || 0;
            const appointments = result.results?.appointments || 0;
            const exercises = result.results?.exercises || 0;
            
            showMessage(`✅ Successfully synced ${medications} medications, ${appointments} appointments, and ${exercises} exercises to Google Calendar!`, 'success');
        } else {
            showMessage(`❌ ${result.message || 'Sync failed'}`, 'error');
        }
    } catch (error) {
        console.error('Error syncing to Google Calendar:', error);
        showMessage('❌ Error syncing to Google Calendar', 'error');
    } finally {
        button.disabled = false;
        button.innerHTML = originalText;
    }
}

let bloodPressureChart, glucoseChart, weightChart;
let editingVitalSignId = null;

async function saveVitalSign(event) {
    event.preventDefault();
    
    const data = {
        recorded_at: document.getElementById('vsDateTime').value,
        systolic: document.getElementById('vsSystolic').value || null,
        diastolic: document.getElementById('vsDiastolic').value || null,
        glucose: document.getElementById('vsGlucose').value || null,
        weight: document.getElementById('vsWeight').value || null,
        notes: document.getElementById('vsNotes').value
    };
    
    if (!data.systolic && !data.diastolic && !data.glucose && !data.weight) {
        showMessage('Please enter at least one vital sign measurement', 'error');
        return;
    }
    
    try {
        const url = editingVitalSignId 
            ? `${API_URL}/vital-signs/${editingVitalSignId}`
            : `${API_URL}/vital-signs`;
        const method = editingVitalSignId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        
        if (response.ok) {
            const message = editingVitalSignId 
                ? 'Vital signs updated successfully!' 
                : 'Vital signs recorded successfully!';
            showMessage(message, 'success');
            clearVitalSignsForm();
            loadVitalSigns();
        }
    } catch (error) {
        console.error('Error saving vital signs:', error);
        showMessage('Error saving vital signs', 'error');
    }
}

function clearVitalSignsForm() {
    document.getElementById('vitalSignsForm').reset();
    editingVitalSignId = null;
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    document.getElementById('vsDateTime').value = now.toISOString().slice(0, 16);
    
    const submitBtn = document.querySelector('#vitalSignsForm button[type="submit"]');
    submitBtn.innerHTML = '💾 Save Vital Signs';
}

function editVitalSign(sign) {
    editingVitalSignId = sign.id;
    
    const recordedDate = new Date(sign.recorded_at);
    recordedDate.setMinutes(recordedDate.getMinutes() - recordedDate.getTimezoneOffset());
    document.getElementById('vsDateTime').value = recordedDate.toISOString().slice(0, 16);
    
    document.getElementById('vsSystolic').value = sign.systolic || '';
    document.getElementById('vsDiastolic').value = sign.diastolic || '';
    document.getElementById('vsGlucose').value = sign.glucose || '';
    document.getElementById('vsWeight').value = sign.weight || '';
    document.getElementById('vsNotes').value = sign.notes || '';
    
    const submitBtn = document.querySelector('#vitalSignsForm button[type="submit"]');
    submitBtn.innerHTML = '✏️ Update Vital Signs';
    
    document.querySelector('#vitalSignsForm').scrollIntoView({ behavior: 'smooth' });
}

async function loadVitalSigns() {
    try {
        const response = await fetch(`${API_URL}/vital-signs`);
        const signs = await response.json();
        
        displayVitalSignsList(signs);
        createCharts(signs);
    } catch (error) {
        console.error('Error loading vital signs:', error);
    }
}

function displayVitalSignsList(signs) {
    const container = document.getElementById('vitalSignsList');
    
    if (signs.length === 0) {
        container.innerHTML = '<p class="empty-state">No vital signs recorded yet. Add your first measurement above!</p>';
        return;
    }
    
    container.innerHTML = signs.map(sign => {
        const date = new Date(sign.recorded_at);
        const dateStr = date.toLocaleDateString();
        const timeStr = date.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
        
        let measurements = [];
        if (sign.systolic && sign.diastolic) {
            const bpClass = getBPClass(sign.systolic, sign.diastolic);
            measurements.push(`<span class="${bpClass}">🩸 BP: ${sign.systolic}/${sign.diastolic} mmHg</span>`);
        }
        if (sign.glucose) {
            const glucoseClass = getGlucoseClass(sign.glucose);
            measurements.push(`<span class="${glucoseClass}">🩹 Glucose: ${sign.glucose} mg/dL</span>`);
        }
        if (sign.weight) {
            measurements.push(`<span>⚖️ Weight: ${sign.weight} lbs</span>`);
        }
        
        return `
            <div class="item-card">
                <div class="item-header">
                    <div>
                        <strong>${dateStr}</strong> at ${timeStr}
                        ${sign.notes ? `<p style="color: var(--dark-gray); margin: 0.25rem 0 0 0; font-size: 0.9rem;">${sign.notes}</p>` : ''}
                    </div>
                    <div style="display: flex; gap: 0.5rem;">
                        <button class="btn btn-primary" onclick='editVitalSign(${JSON.stringify(sign)})'>Edit</button>
                        <button class="btn btn-danger" onclick="deleteVitalSign(${sign.id})">Delete</button>
                    </div>
                </div>
                <div style="margin-top: 0.5rem; display: flex; flex-wrap: wrap; gap: 1rem; font-size: 0.95rem;">
                    ${measurements.join('')}
                </div>
            </div>
        `;
    }).join('');
}

function getBPClass(systolic, diastolic) {
    if (systolic >= 140 || diastolic >= 90) return 'status-overdue';
    if (systolic >= 130 || diastolic >= 80) return 'status-pending';
    return 'status-taken';
}

function getGlucoseClass(glucose) {
    if (glucose < 70 || glucose > 180) return 'status-overdue';
    if (glucose >= 140) return 'status-pending';
    return 'status-taken';
}

async function deleteVitalSign(id) {
    if (!confirm('Are you sure you want to delete this vital sign record?')) return;
    
    try {
        const response = await fetch(`${API_URL}/vital-signs/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showMessage('Vital sign deleted successfully', 'success');
            loadVitalSigns();
        }
    } catch (error) {
        console.error('Error deleting vital sign:', error);
        showMessage('Error deleting vital sign', 'error');
    }
}

function createCharts(signs) {
    if (signs.length === 0) return;
    
    const sortedSigns = [...signs].reverse();
    const labels = sortedSigns.map(s => {
        const date = new Date(s.recorded_at);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    });
    
    createBloodPressureChart(sortedSigns, labels);
    createGlucoseChart(sortedSigns, labels);
    createWeightChart(sortedSigns, labels);
}

function createBloodPressureChart(signs, labels) {
    const systolicData = signs.map(s => s.systolic);
    const diastolicData = signs.map(s => s.diastolic);
    
    const hasBPData = systolicData.some(v => v != null) || diastolicData.some(v => v != null);
    
    if (!hasBPData) {
        document.getElementById('bloodPressureChart').parentElement.innerHTML = '<p class="empty-state">No blood pressure data recorded yet</p>';
        return;
    }
    
    const ctx = document.getElementById('bloodPressureChart').getContext('2d');
    if (bloodPressureChart) bloodPressureChart.destroy();
    
    bloodPressureChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Systolic',
                    data: systolicData,
                    borderColor: '#e91e63',
                    backgroundColor: 'rgba(233, 30, 99, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Diastolic',
                    data: diastolicData,
                    borderColor: '#2196F3',
                    backgroundColor: 'rgba(33, 150, 243, 0.1)',
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Blood Pressure Trends (mmHg)',
                    font: {size: 16}
                },
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    title: {
                        display: true,
                        text: 'mmHg'
                    }
                }
            }
        }
    });
}

function createGlucoseChart(signs, labels) {
    const glucoseData = signs.map(s => s.glucose);
    
    const hasGlucoseData = glucoseData.some(v => v != null);
    
    if (!hasGlucoseData) {
        document.getElementById('glucoseChart').parentElement.innerHTML = '<p class="empty-state">No glucose data recorded yet</p>';
        return;
    }
    
    const ctx = document.getElementById('glucoseChart').getContext('2d');
    if (glucoseChart) glucoseChart.destroy();
    
    glucoseChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Blood Glucose',
                data: glucoseData,
                borderColor: '#e91e63',
                backgroundColor: 'rgba(233, 30, 99, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Blood Glucose Trends (mg/dL)',
                    font: {size: 16}
                },
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    title: {
                        display: true,
                        text: 'mg/dL'
                    }
                }
            }
        }
    });
}

function createWeightChart(signs, labels) {
    const weightData = signs.map(s => s.weight);
    
    const hasWeightData = weightData.some(v => v != null);
    
    if (!hasWeightData) {
        document.getElementById('weightChart').parentElement.innerHTML = '<p class="empty-state">No weight data recorded yet</p>';
        return;
    }
    
    const ctx = document.getElementById('weightChart').getContext('2d');
    if (weightChart) weightChart.destroy();
    
    weightChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Weight',
                data: weightData,
                borderColor: '#4CAF50',
                backgroundColor: 'rgba(76, 175, 80, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Weight Trends (lbs)',
                    font: {size: 16}
                },
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    title: {
                        display: true,
                        text: 'lbs'
                    }
                }
            }
        }
    });
}

async function importAppleHealth() {
    const fileInput = document.getElementById('appleHealthFile');
    const statusDiv = document.getElementById('importStatus');
    
    if (!fileInput.files || !fileInput.files[0]) {
        showMessage('Please select a CSV file first', 'error');
        return;
    }
    
    const file = fileInput.files[0];
    statusDiv.innerHTML = '<p style="color: var(--primary-blue);">📊 Reading and parsing file...</p>';
    
    try {
        const text = await file.text();
        const lines = text.split('\n');
        
        if (lines.length < 2) {
            statusDiv.innerHTML = '<p style="color: var(--error-red);">❌ File appears to be empty</p>';
            return;
        }
        
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const records = [];
        
        const typeIndex = headers.indexOf('type');
        const startDateIndex = headers.indexOf('startDate');
        const valueIndex = headers.indexOf('value');
        const unitIndex = headers.indexOf('unit');
        
        if (typeIndex === -1 || startDateIndex === -1 || valueIndex === -1) {
            statusDiv.innerHTML = '<p style="color: var(--error-red);">❌ Invalid Apple Health CSV format. Make sure you exported the correct file.</p>';
            return;
        }
        
        const vitalSignsMap = new Map();
        
        for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            
            const values = line.match(/(".*?"|[^,]+)(?=\s*,|\s*$)/g) || [];
            const cleanValues = values.map(v => v.replace(/"/g, '').trim());
            
            const type = cleanValues[typeIndex];
            const startDate = cleanValues[startDateIndex];
            const value = parseFloat(cleanValues[valueIndex]);
            const unit = cleanValues[unitIndex];
            
            if (!startDate || isNaN(value)) continue;
            
            const dateKey = startDate.substring(0, 16);
            
            if (!vitalSignsMap.has(dateKey)) {
                vitalSignsMap.set(dateKey, {
                    recorded_at: startDate,
                    systolic: null,
                    diastolic: null,
                    glucose: null,
                    weight: null,
                    notes: 'Imported from Apple Health'
                });
            }
            
            const record = vitalSignsMap.get(dateKey);
            
            if (type === 'HKQuantityTypeIdentifierBloodPressureSystolic' || type.includes('BloodPressureSystolic')) {
                record.systolic = Math.round(value);
            } else if (type === 'HKQuantityTypeIdentifierBloodPressureDiastolic' || type.includes('BloodPressureDiastolic')) {
                record.diastolic = Math.round(value);
            } else if (type === 'HKQuantityTypeIdentifierBloodGlucose' || type.includes('BloodGlucose')) {
                record.glucose = unit === 'mmol/L' ? Math.round(value * 18.0182) : Math.round(value);
            } else if (type === 'HKQuantityTypeIdentifierBodyMass' || type.includes('BodyMass')) {
                record.weight = unit === 'kg' ? Math.round(value * 2.20462 * 10) / 10 : Math.round(value * 10) / 10;
            }
        }
        
        const validRecords = Array.from(vitalSignsMap.values()).filter(r => 
            r.systolic || r.diastolic || r.glucose || r.weight
        );
        
        if (validRecords.length === 0) {
            statusDiv.innerHTML = '<p style="color: var(--warning-yellow);">⚠️ No vital signs data found in the file. Make sure your Apple Health export contains blood pressure, glucose, or weight measurements.</p>';
            return;
        }
        
        statusDiv.innerHTML = `<p style="color: var(--primary-blue);">📤 Importing ${validRecords.length} vital sign records...</p>`;
        
        const response = await fetch(`${API_URL}/vital-signs/bulk-import`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({records: validRecords})
        });
        
        if (response.ok) {
            const result = await response.json();
            statusDiv.innerHTML = `<p style="color: var(--success-green); font-weight: 600;">✅ Successfully imported ${result.imported} vital sign records from Apple Health!</p>`;
            showMessage(`Successfully imported ${result.imported} records!`, 'success');
            fileInput.value = '';
            loadVitalSigns();
        } else {
            const error = await response.json();
            statusDiv.innerHTML = `<p style="color: var(--error-red);">❌ Import failed: ${error.message || 'Unknown error'}</p>`;
        }
    } catch (error) {
        console.error('Error importing Apple Health data:', error);
        statusDiv.innerHTML = `<p style="color: var(--error-red);">❌ Error reading file: ${error.message}</p>`;
        showMessage('Error importing Apple Health data', 'error');
    }
}
